#include <Arduino.h>

#define SER 13   // Data PIN 14 (SER)
#define SRCLK 12 // Clock de desplazamiento PIN 11 (SRCLK)
#define RCLK 11  // Clock Store PIN 12 (RCLK)

uint8_t secuencia_1[8] = {
    B10000000,
    B01000000,
    B00100000,
    B00010000,
    B00001000,
    B00000100,
    B00000010,
    B00000001
    };

uint8_t secuencia_2[9] = {

    0b00000000,
    0b10000001,
    0b11000011,
    0b11100111,
    0b11111111,
    0b11100111,
    0b11000011,
    0b10000001,
    0b00000000,

};
    

/*
************************************************
            PROTOTIPO DE FUNCIONES
************************************************
*/

void shiftClock();
void shiftLatch();
void shiftWrite(uint8_t data);



void setup()
{
  pinMode(SER, OUTPUT);
  pinMode(SRCLK, OUTPUT);
  pinMode(RCLK, OUTPUT);
}

void loop()
{

  for (int i = 0; i < 8; i++)
  {
    shiftWrite(secuencia_1[i]);
    delay(80);
  }

  for (int j = 7; j >= 0; j--)
  {
    shiftWrite(secuencia_1[j]);
    delay(80);
  }

    for (int i = 0; i < 9; i++)
  {
    shiftWrite(secuencia_2[i]);
    delay(60);
  }

}




/*
************************************************
                   FUNCIONES
************************************************
*/

void shiftClock() // Señal de reloj
{
  digitalWrite(SRCLK, HIGH);
  delayMicroseconds(100);
  digitalWrite(SRCLK, LOW);
  delayMicroseconds(100);
}

void shiftLatch() // Pulso store
{
  digitalWrite(RCLK, HIGH);
  delayMicroseconds(100);
  digitalWrite(RCLK, LOW);
  delayMicroseconds(100);
}

void shiftWrite(uint8_t data)
{

  for (int i = 0; i < 8; i++)
  {

    if (data & B10000000)
    {
      digitalWrite(SER, HIGH);
    }
    else
    {
      digitalWrite(SER, LOW);
    }
    shiftClock();
    data = data << 1;
  }

  digitalWrite(SER, LOW);
  shiftLatch(); // Pulso de store
}
