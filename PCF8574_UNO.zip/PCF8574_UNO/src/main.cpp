#include <Arduino.h>
#include <Wire.h>

byte PCF = 0x20;

void setup()
{
  Wire.begin();
  Wire.setClock(50000);
  Serial.begin(9600);

  delay(200);

  // Leer Device ID
  /*
  Serial.println("Lectura de IC:");
  Wire.beginTransmission(FDC);
  Wire.write(0xFF);
  Wire.endTransmission();
  delay(10);
  Wire.requestFrom(FDC, 2);
  byte MSB_DID = Wire.read();
  byte LSB_DID = Wire.read();

  uint16_t DID = MSB_DID << 8;
  DID |= LSB_DID;

  Serial.print("Device ID: ");
  Serial.println(DID, HEX);
*/
  delay(100);
}

void loop()
{


  Wire.beginTransmission(PCF);
  Wire.write(B00010000);
  Wire.endTransmission();

  delay(70);

  Wire.beginTransmission(PCF);
  Wire.write(B00110000);
  Wire.endTransmission();

  delay(70);

  Wire.beginTransmission(PCF);
  Wire.write(B01110000);
  Wire.endTransmission();

  delay(70);

  Wire.beginTransmission(PCF);
  Wire.write(B00000000);
  Wire.endTransmission();

  delay(70);



  Wire.beginTransmission(PCF);
  Wire.write(B01000000);
  Wire.endTransmission();
  delay(70);

 Wire.beginTransmission(PCF);
  Wire.write(B01100000);
  Wire.endTransmission();
  delay(70);


 Wire.beginTransmission(PCF);
  Wire.write(B01110000);
  Wire.endTransmission();
  delay(70);
}
